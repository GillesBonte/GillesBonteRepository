﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExOef2RepositoryPattern.Models
{
    //deze klasse is de modelklasse voor Customer
    public class Customer
    {
    }
}
